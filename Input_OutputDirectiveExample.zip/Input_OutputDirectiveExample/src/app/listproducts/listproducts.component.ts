import { Component ,EventEmitter,Input, Output } from '@angular/core';
import { Product } from 'src/models/Product';

@Component({
  selector: 'app-listproducts',
  templateUrl: './listproducts.component.html',
  styleUrls: ['./listproducts.component.css']
})
export class ListproductsComponent
{
  @Input() pt : any

  @Output() delrec : EventEmitter<Product>  = new EventEmitter<Product>()

  fetchproduct(pdrec : Product)
  {
      this.delrec.emit(pdrec)
  }

}
