import { ChangeDetectionStrategy, Component ,OnInit , Input } from '@angular/core';

@Component({
  selector: 'app-child',
  changeDetection:  ChangeDetectionStrategy.Default,
  template: `

              Message from Parent : {{msgfromparent}}<br>

              <app-grandchild [objfromparent]="obj"></app-grandchild>

              `,
  styleUrls: []
})
export class ChildComponent implements OnInit
{

  obj=[{}]


  @Input() msgfromparent ?:any

  constructor() {
    this.obj = [
      {pid:101,pnm:'headset'},
      {pid:102,pnm:'speaker'}]
    }


  ngOnChanges()
  {
    console.log(" Child Component OnChange")
  }

  ngOnInit(): void {
    console.log("  Child Component onInit")
  }

  ngDoCheck()
  {
    console.log(" Child Component  doCheck")
  }

  ngAfterContentInit()
  {
    console.log(" Child Component  ngAfterContentInit")
  }

  ngAfterContentChecked()
  {
    console.log(" Child Component  ngAfterContentChecked")
  }
  ngAfterViewInit()
  {
    console.log(" Child Component  ngAfterViewInit")
  }
  ngAfterViewChecked()
  {
    console.log(" Child Component ngAfterViewChecked")
  }


}
