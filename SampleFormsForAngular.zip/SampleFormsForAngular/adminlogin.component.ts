import { Component } from '@angular/core';

@Component({
  selector: 'app-adminlogin',
  template:`
          <div class="container ms-5 ps-5 mt-5">
              <div class="text-center">
                <h1 class="mb-5"> Administrator Login </h1>
              </div>
              <div class="container p-2">
                <form class="form-group">
                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="usr"> User Email : </label>
                        </div>
                        <div class="col-lg-6">
                          <input class="form-control border-0 border-bottom border-danger " type="text" id="usr" name="usr"/>
                        </div>
                  </div>

                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="usr"> Password : </label>
                        </div>
                        <div class="col-lg-6">
                          <input class="form-control border-0 border-bottom border-danger " type="password" id="pwd" name="pwd"/>
                        </div>
                  </div>

                  <div class="row mb-4">
                        <div class="col-lg-4 ">

                        </div>
                        <div class="col-lg-6">
                        <button type="button" class="btn btn-danger "> CreateUser </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <button type="button" class="btn btn-danger"> Login </button>
                        </div>
                  </div>
                </form>
              </div>
          </div>
  `,
  styles: [``]
})

export class AdminloginComponent
{

}
