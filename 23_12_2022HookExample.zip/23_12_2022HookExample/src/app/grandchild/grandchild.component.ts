import { ChangeDetectionStrategy, Component,OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-grandchild',
  changeDetection:  ChangeDetectionStrategy.Default,
  template: `

  Message from Child to GrandChild :
  <ul *ngFor='let t of objfromparent'>
      <li>{{t.pid}}  -  {{t.pnm}}</li>
  </ul>
  `,
  styleUrls: []
})
export class GrandchildComponent implements OnInit
{
@Input() objfromparent?:any

  constructor() { }


  ngOnChanges()
  {
    console.log(" GrandChild Component OnChange")
  }

  ngOnInit(): void {
    console.log("  GrandChild Component onInit")
  }

  ngDoCheck()
  {
    console.log(" GrandChild Component  doCheck")
  }

  ngAfterContentInit()
  {
    console.log(" GrandChild Component  ngAfterContentInit")
  }

  ngAfterContentChecked()
  {
    console.log(" GrandChild Component  ngAfterContentChecked")
  }
  ngAfterViewInit()
  {
    console.log(" GrandChild Component  ngAfterViewInit")
  }
  ngAfterViewChecked()
  {
    console.log(" GrandChild Component ngAfterViewChecked")
  }


}
