export class Product
{
  prnm?:string
  price?:number
  qty?:number
  dt?:Date
}
