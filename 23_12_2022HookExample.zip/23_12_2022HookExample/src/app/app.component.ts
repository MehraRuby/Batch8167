import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  changeDetection:  ChangeDetectionStrategy.Default,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'HookExample';

msg = "Hello"
ct="Angular"
hide=false


  constructor() { }


  ngOnChanges()
  {
    console.log(" App Component OnChange")
  }

  ngOnInit(): void {
    console.log("  App Component onInit")
  }

  ngDoCheck()
  {
    console.log(" App Component  doCheck")
  }

  ngAfterContentInit()
  {
    console.log(" App Component  ngAfterContentInit")
  }

  ngAfterContentChecked()
  {
    console.log(" App Component  ngAfterContentChecked")
  }
  ngAfterViewInit()
  {
    console.log(" App Component  ngAfterViewInit")
  }
  ngAfterViewChecked()
  {
    console.log(" App Component ngAfterViewChecked")
  }

}
