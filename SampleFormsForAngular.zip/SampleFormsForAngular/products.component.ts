import { Component } from '@angular/core';

@Component({
  selector: 'app-products',
  template:`
<div class="container ms-5 ps-5 mt-5">
              <div class="text-center">
                <h1 class="mb-5"> Add Product Details </h1>
              </div>
              <div class="container p-2">
                <form class="form-group">
                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="prnm"> Product Name : </label>
                        </div>
                        <div class="col-lg-6">
                          <input class="form-control border-0 border-bottom border-danger " type="text" id="prnm" name="prnm"/>
                        </div>
                  </div>

                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="price"> Price : </label>
                        </div>
                        <div class="col-lg-6">
                          <input class="form-control border-0 border-bottom border-danger " type="text" id="price" name="price"/>
                        </div>
                  </div>

                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="qty"> Quantity : </label>
                        </div>
                        <div class="col-lg-6">
                          <input class="form-control border-0 border-bottom border-danger " type="text" id="qty" name="qty"/>
                        </div>
                  </div>

                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="desc"> Description : </label>
                        </div>
                        <div class="col-lg-6">
                          <textarea class="form-control border-0 border-bottom border-danger "
                          rows="5" cols="20" id="desc" name="desc"></textarea>
                        </div>
                  </div>

                  <div class="row mb-4">
                        <div class="col-lg-4 text-center">
                          <label for="price"> Upload Image : </label>
                        </div>
                        <div class="col-lg-6">
                          <input class="form-control border-0 border-bottom border-danger " type="file" id="file" name="file"/>
                        </div>
                  </div>


                  <div class="row mb-4">
                        <div class="col-lg-4">

                        </div>
                        <div class="col-lg-6">
                          <button type="button" class="btn btn-danger"> Add Product </button>
                        </div>
                  </div>
                </form>
              </div>
          </div>





  `,
  styles: [``]
})
export class ProductsComponent {

}
